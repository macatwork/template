﻿cd ~
cd .\Documents\Adapt
mkdir NewProject
cd NewProject
mkdir Assets
mkdir Assets/Image, Assets/Icons, Assets/Fonts
new-item index.html, adapt.css, style.css, script.js, ReadMe.md
get-content ../Templates/index.html | add-content index.html
get-content ../Templates/adapt.css  | add-content adapt.css
get-content ../Templates/style.css  | add-content style.css
get-content ../Templates/script.js  | add-content script.js
get-content ../Templates/ReadMe.md  | add-content ReadMe.md